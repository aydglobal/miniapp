import React from "react";
import { motion, AnimatePresence } from "framer-motion";

type Props = { onTap: () => void; floatingGain?: number | null; };

export default function TapCore({ onTap, floatingGain }: Props) {
  return (
    <div className="relative flex items-center justify-center">
      <motion.button whileTap={{ scale: 0.93 }} whileHover={{ scale: 1.02 }} onClick={onTap} className="adn-tap-core relative flex items-center justify-center text-xl font-extrabold">
        TAP
      </motion.button>
      <AnimatePresence>
        {floatingGain ? (
          <motion.div
            key={floatingGain}
            initial={{ y: 0, opacity: 1, scale: 1 }}
            animate={{ y: -42, opacity: 0, scale: 1.05 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.55, ease: "easeOut" }}
            className="pointer-events-none absolute text-lg font-bold text-emerald-500"
          >
            +{floatingGain}
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
  );
}
