import React from "react";
import Card from "./Card";
import Button from "./Button";

type Props = { title: string; subtitle: string; timeLeft: string; };

export default function EventBanner({ title, subtitle, timeLeft }: Props) {
  return (
    <Card strong className="p-5">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <div className="adn-label">Live Event</div>
          <div className="mt-2 text-2xl font-bold">{title}</div>
          <p className="mt-1 text-sm text-muted">{subtitle}</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="adn-badge adn-badge-gold">Ends in {timeLeft}</div>
          <Button variant="gold">Join Event</Button>
        </div>
      </div>
    </Card>
  );
}
