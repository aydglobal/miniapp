import React from "react";
import clsx from "clsx";

type Props = React.HTMLAttributes<HTMLDivElement> & { strong?: boolean; };

export default function Card({ strong, className, children, ...props }: Props) {
  return (
    <div className={clsx(strong ? "adn-panel-strong" : "adn-panel", "adn-interactive", className)} {...props}>
      {children}
    </div>
  );
}
