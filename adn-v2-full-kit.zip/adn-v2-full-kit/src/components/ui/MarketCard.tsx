import React from "react";
import Card from "./Card";
import Button from "./Button";

type Props = {
  category: string;
  title: string;
  level: number;
  currentValue: string;
  nextValue: string;
  cost: string;
  onBuy?: () => void;
};

export default function MarketCard({ category, title, level, currentValue, nextValue, cost, onBuy }: Props) {
  return (
    <Card className="p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="adn-badge">{category}</div>
        <div className="adn-badge adn-badge-active">Lv. {level}</div>
      </div>
      <div className="mt-4 text-lg font-bold">{title}</div>
      <div className="mt-2 text-sm text-muted">
        <span className="font-medium text-text">{currentValue}</span> → <span className="font-medium text-primaryStrong">{nextValue}</span>
      </div>
      <Button variant="primary" className="mt-4 w-full" onClick={onBuy}>
        Buy · {cost}
      </Button>
    </Card>
  );
}
