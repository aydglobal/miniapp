import React from "react";
import Card from "./Card";
import Button from "./Button";
import ProgressBar from "./ProgressBar";

type MissionStatus = "active" | "inProgress" | "claimable" | "completed";
type Props = {
  reward: string;
  title: string;
  description: string;
  progress: number;
  maxProgress: number;
  status: MissionStatus;
  onAction?: () => void;
};

export default function MissionCard({ reward, title, description, progress, maxProgress, status, onAction }: Props) {
  const label = status === "claimable" ? "Claim Reward" : status === "completed" ? "Completed" : "Go Mission";
  return (
    <Card className={`p-5 ${status === "claimable" ? "adn-glow-gold" : ""}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="adn-badge adn-badge-gold">{reward}</div>
        <div className={`adn-badge ${status === "claimable" ? "adn-badge-active" : ""}`}>{status}</div>
      </div>
      <div className="mt-4 text-lg font-bold">{title}</div>
      <p className="mt-1 text-sm text-muted">{description}</p>
      <div className="mt-4"><ProgressBar value={progress} max={maxProgress} variant="gold" /></div>
      <Button variant={status === "claimable" ? "gold" : "secondary"} className="mt-4 w-full" disabled={status === "completed"} onClick={onAction}>
        {label}
      </Button>
    </Card>
  );
}
