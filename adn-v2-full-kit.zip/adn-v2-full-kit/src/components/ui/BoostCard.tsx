import React from "react";
import Card from "./Card";
import Button from "./Button";

type Props = { name: string; duration: string; maxLevel: number; active?: boolean; remaining?: string; };

export default function BoostCard({ name, duration, maxLevel, active = false, remaining }: Props) {
  return (
    <Card className={`p-5 ${active ? "adn-glow" : ""}`}>
      <div className="flex items-start justify-between gap-3">
        <div className={`adn-badge ${active ? "adn-badge-active" : ""}`}>{active ? `Active · ${remaining}` : "Boost"}</div>
        <div className="adn-badge">Max {maxLevel}</div>
      </div>
      <div className="mt-4 text-lg font-bold">{name}</div>
      <div className="mt-1 text-sm text-muted">Duration: {duration}</div>
      <div className="mt-4 grid grid-cols-3 gap-2">
        <Button variant="primary" className="w-full">Buy</Button>
        <Button variant="secondary" className="w-full">Free</Button>
        <Button variant="gold" className="w-full">Star</Button>
      </div>
    </Card>
  );
}
