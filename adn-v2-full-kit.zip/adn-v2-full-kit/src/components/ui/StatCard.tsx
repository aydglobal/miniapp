import React from "react";
import Card from "./Card";

type Props = { label: string; value: string; help?: string; rightBadge?: string; };

export default function StatCard({ label, value, help, rightBadge }: Props) {
  return (
    <Card className="p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="adn-label">{label}</div>
          <div className="adn-stat-value mt-2">{value}</div>
          {help ? <div className="adn-stat-help">{help}</div> : null}
        </div>
        {rightBadge ? <div className="adn-badge adn-badge-active">{rightBadge}</div> : null}
      </div>
    </Card>
  );
}
