import React from "react";
import Card from "./Card";
import Button from "./Button";
import ProgressBar from "./ProgressBar";

type Props = { gain: number; ready: boolean; progress: number; onReboot: () => void; };

export default function RbrtPanel({ gain, ready, progress, onReboot }: Props) {
  return (
    <Card strong className="p-5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="adn-label">RBRT System</div>
          <div className="mt-2 text-2xl font-bold text-text">+{gain} Power</div>
          <div className="mt-1 text-sm text-muted">Progress resetlenir, kalıcı güç korunur.</div>
        </div>
        <div className={`adn-badge ${ready ? "adn-badge-rbrt animate-soft-pulse" : ""}`}>
          {ready ? "Ready" : "Charging"}
        </div>
      </div>
      <div className="mt-4"><ProgressBar value={progress} variant="rbrt" /></div>
      <div className="mt-4">
        <Button variant="rbrt" onClick={onReboot} disabled={!ready} className="w-full justify-center">
          REBOOT
        </Button>
      </div>
    </Card>
  );
}
