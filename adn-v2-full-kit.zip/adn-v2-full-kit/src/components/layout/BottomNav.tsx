import React from "react";
import clsx from "clsx";
import { Home, ListChecks, ShoppingBag, Zap, User } from "lucide-react";

type Tab = "home" | "tasks" | "market" | "boost" | "profile";
type Props = { active: Tab; onChange: (tab: Tab) => void; };

const items = [
  { key: "home", label: "Home", icon: Home },
  { key: "tasks", label: "Tasks", icon: ListChecks },
  { key: "market", label: "Market", icon: ShoppingBag },
  { key: "boost", label: "Boost", icon: Zap },
  { key: "profile", label: "Profile", icon: User },
] as const;

export default function BottomNav({ active, onChange }: Props) {
  return (
    <div className="fixed bottom-4 left-1/2 z-50 w-[calc(100%-24px)] max-w-md -translate-x-1/2 rounded-3xl adn-nav px-2 py-2">
      <div className="grid grid-cols-5 gap-1">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = active === item.key;
          return (
            <button
              key={item.key}
              onClick={() => onChange(item.key)}
              className={clsx(
                "flex flex-col items-center justify-center rounded-2xl px-2 py-2 transition-all duration-200",
                isActive ? "bg-white shadow-soft text-text" : "text-softText hover:bg-white/60"
              )}
            >
              <Icon className={clsx("h-4 w-4", isActive && "text-primaryStrong")} />
              <span className="mt-1 text-[11px] font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
