import React from "react";

type Props = { title?: string; subtitle?: string; children: React.ReactNode; };

export default function AppShell({ title, subtitle, children }: Props) {
  return (
    <div className="adn-shell">
      <div className="adn-container py-6 md:py-8">
        {(title || subtitle) && (
          <div className="mb-6 md:mb-8">
            {title ? <h1 className="adn-title">{title}</h1> : null}
            {subtitle ? <p className="adn-subtitle mt-2 max-w-2xl">{subtitle}</p> : null}
          </div>
        )}
        {children}
      </div>
    </div>
  );
}
